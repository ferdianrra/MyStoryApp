package com.dicoding.mystoryapp.network.pref

data class UserModel (
    val token: String?
)