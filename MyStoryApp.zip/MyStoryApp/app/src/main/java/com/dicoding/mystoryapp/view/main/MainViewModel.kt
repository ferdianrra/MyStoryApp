package com.dicoding.mystoryapp.view.main

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.dicoding.mystoryapp.data.FeedsRepository
import com.dicoding.mystoryapp.network.UserRepository
import com.dicoding.mystoryapp.network.pref.UserModel
import com.dicoding.mystoryapp.network.response.ListStoryItem
import com.dicoding.mystoryapp.network.response.StoryResponse
import com.dicoding.mystoryapp.network.retrofit.ApiConfig
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainViewModel (val repository: UserRepository, feedsRepository: FeedsRepository) : ViewModel() {
    val feedsPhoto : LiveData<PagingData<ListStoryItem>> = feedsRepository.getFeeds().cachedIn(viewModelScope)

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading : LiveData<Boolean> = _isLoading

    init {
        _isLoading.value = true
    }

    fun getSession(): LiveData<UserModel> {
        _isLoading.value = false
        return repository.getSession().asLiveData()
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }

    companion object {
        private const val TAG = "MainViewModel"
    }
}